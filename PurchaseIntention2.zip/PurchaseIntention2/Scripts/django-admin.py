#!c:\users\muhamm~1\desktop\fyp-ii\purcha~2\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
