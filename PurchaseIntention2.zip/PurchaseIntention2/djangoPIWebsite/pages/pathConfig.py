PATH_CONFIG = {
    'pathData' : 'data\Annotated4.csv', #Windows data path
    'pathStopWords' : 'models\stopwords.txt',          #Windows stopwords path
    #"pathData": "data/AnnotatedData3.csv",  # Ubuntu data path
    #"pathStopWords": "models/stopwords.txt",  # Ubuntu stopwords path

}
